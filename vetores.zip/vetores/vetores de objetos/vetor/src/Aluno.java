public class Aluno {
    private String rgm;
    private float nota;
    private float media;
    
    public Aluno(String rgm, float nota, float media) {
        this.rgm = rgm;
        this.nota = nota;
        this.media = media;
    }

    public String getRgm() {
        return rgm;
    }

    public void setRgm(String rgm) {
        this.rgm = rgm;
    }

    public float getNota() {
        return nota;
    }

    public void setNota(float nota) {
        this.nota = nota;
    }

    public float getMedia() {
        return media;
    }

    public void setMedia(float media) {
        this.media = media;
    }

    
}
