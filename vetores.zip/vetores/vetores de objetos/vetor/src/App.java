import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner leia = new Scanner(System.in);
        Aluno aluno[] = new Aluno[10];
        
        



    }
}
