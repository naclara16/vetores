public class App {
    public static void main(String[] args) throws Exception {
       String[] vetor1, vetor2;
       vetor1 = new String[2];
       vetor2 = new String [5];

       float[] vetor3 = new float[3];

       int[] vetor4 = {1,2,3,4};

       //acessar os 


    }
}
