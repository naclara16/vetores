public class App {
    public static void main(String[] args) throws Exception {
        
        int[] lista = new int[10];
        int[] numeros = {1, 2, 3};
        //int[][] tabela = {/*tabela de tamanho variavel */ {1, 2, 3}, {4, 5}, {6, 7, 8, 9}};

        System.out.println("O tamanho da lista é: " + lista.length);
        System.out.println("O tamanho de numeros é: " + numeros.length);
    }
}
